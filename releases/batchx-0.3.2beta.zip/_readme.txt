*** MANUAL ***
* Written by lonesentinel19 *

Information is available online at: https://github.com/lonesentinel19/BatchX/wiki
Also on GitHub is the full source code and other helpful features.

To run:
	batchx.exe [batch file] [file to be transpiled to]

Extensions:
	*.batx


!! Commands
* -START-
This signifies the start of the file. The Batch equivalent is "@echo off".

* -STARTX-
This is similar to -START-, but also adds "SETLOCAL ENABLEEXTENSIONS".

* var
One can define variables now using "var" instead of int. This is equivalent to SET.
Examples
	* var a=This is a variable

* int
This is for basic mathematics, equivalent to "SET /A".
	* int a=3*3

* input
This is equivalent to "SET /P". It allows inputs to be taken and stored in a variable.

* // 
A comment, replaced with "REM". Equivalent also to "::".

* def
Defines a goto location. Equivalent to ":location". "def" must be the first three characters of a line
or it will throw an error.

* -END-
Siginifies end of file. Whereas -START- is optional, -END- is mandatory and must be included or an error
will be thrown.

* Classes
One can now specify classes! Now any variable that is constructed inside of the class will be prepended with the class 
name. The same goes to any function constructed in the same way.

	Example:
		class test {
			def hello
			var a=Hi
			echo %a%
			}

		var a=Hello
		echo %a%
		goto test.hello

The output will be "
Hi
Hello
" because the variables will not collide!

To call a class variable specifically, one must do [classname].[variable] (without brackets).
To call a function from a class, one must do [classname].[function] (without brackets).

* del
Syntax: del(variables)
This will delete the variable. You can delete multiple variables at once by separting by a comma. No spaces!
	del(var1,var2,var3)

* Tabbing
One may now use tabbing with Batch. The tab will be replaced when transpiled. This is useful for showing outlines of text
such as classes and functions perhaps.

* Update
By writing:
	batchx.exe update
BatchX will compare your version versus the most recent version and inform you if you need to update.

* Array
To form an array:
	var myArray=array(value1,value2,value3)

* Arrset
Set a value (array, index, value)
	arrset(myArray,0,myValue) # Sets myArray 0th index to myValue

* Arrval
Read a value (array, index)
	arrval(myArray,0)
Alternately, if you write in a string rather than a number, it will give you the index of that string inside
your array. Pretty intuitive, huh?

* Arread
This will be replaced with all the values found in the array.
	arread(myArray)
